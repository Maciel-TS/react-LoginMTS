import GoogleLogin from './GoogleLogin.js';

export { GoogleLogin };
